## ----first, include=FALSE, purl=TRUE, message=FALSE----------------------
# This code chunk contains R code already described in the previous chapters
# that is required by following examples

## Datasets from packages
# none

## Other datasets used
# none

###########################
## packages needed: none ##
###########################

