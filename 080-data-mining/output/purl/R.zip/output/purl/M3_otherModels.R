############################################################################
##                                                                        ##
##                            STATISTICS WITH R                           ##
##                              Other Models                              ##
##                                                                        ##
############################################################################

### Set working directory
setwd("data/allData")


### Load libraries
library(nnet)
library(rpart)
library(mgcv)
library(MASS)


### General options
# Read strings as character
options(stringsAsFactors = FALSE)


############################################################################
##                              Titanic  example                          ##
############################################################################

## Data description
# Binomial data
# Data from surviving to Titanic wreck

rm(list=ls())

### Data loading
load("titanic.Rda")
head(titanic)
str(titanic)

## Logistic model
fm1=glm(Status ~ Class+Gender+Class:Gender+Age, data = titanic, family = binomial)
summary(fm1)

fm2=glm(Status ~ Class+Gender+Class:Gender+Age+Class:Age, data = titanic, family = binomial)
summary(fm2)

anova(fm1,fm2,test="LRT")

fm3=glm(Status ~ Class+Gender+Class:Gender+Age+Gender:Age, data = titanic, family = binomial)
summary(fm3)

anova(fm1,fm3,test="LRT")

predglm=predict(fm1,type="response")


## Neural network
nn0=nnet(Status ~ Class+Gender+Age,data=titanic,size=3)

prednn=predict(nn0)


## Regression tree
rt0=rpart(Status ~ Class+Gender+Age,data=titanic)

predrt=predict(rt0)[,2]


## Comparison among logistic model, neural network and regression tree
titanic$predglm=(predglm<.5) ## TRUE=Dead
titanic$prednn=(prednn<.5)  ## TRUE=Dead
titanic$predrt=(predrt<.5)  ## TRUE=Dead

table(titanic$Status,titanic$predglm)
table(titanic$Status,titanic$prednn)
table(titanic$Status,titanic$predrt)

############################################################################
##                                 GAM  example                           ##
############################################################################

## Data description
# Normal data (Extending the linear model with R)
# Ozone data from Breiman and Friedman, 1985
# O3: Ozone conc., ppm, at Sandbug AFB.
# temp: Temperature F. (max?).
# Ibh: Inversion base height, feet
# Pres: Daggett pressure gradient (mm Hg)
# Vis: Visibility (miles)
# Hgt: Vandenburg 500 millibar height (m)
# Hum: Humidity, percent
# Ibt: Inversion base temperature, degrees F.
# Wind: Wind speed, mph

rm(list=ls())
load("ozone.Rda")

str(ozone)
head(ozone)

ammgcv = gam(O3 ~ s(temp)+s(ibh)+s(ibt),data=ozone)
summary(ammgcv)

op=par(mfrow=c(1,3))
plot(ammgcv)
par(op)

# Linear component for temp
am1 = gam(O3 ~ s(temp)+s(ibh), data=ozone)
am2 = gam(O3 ~ temp+s(ibh), data=ozone)
anova(am2,am1,test="F")

## Adding interaction
amint <- gam(O3 ~ s(temp, ibh)+s(ibt), data=ozone)
summary(amint)

anova(ammgcv,amint,test="F")

op=par(mfrow=c(1,3))
plot(amint)
vis.gam(amint,theta=-45,color="gray")
par(op)


## Use the simpler model to produce residuals analysis
op=par(mfrow=c(1,2))
plot (predict (ammgcv), residuals
      (ammgcv),xlab="Predicted",ylab="Residuals")
qqnorm (residuals (ammgcv), main="")
qqline(residuals (ammgcv))
par(op)


# Try another model using Gamma distribution
ammgcv = gam(O3 ~ s(temp)+s(ibh)+s(ibt),data=ozone,family=Gamma(link="identity"))
summary(ammgcv)

op=par(mfrow=c(1,2))
plot (predict (ammgcv), residuals
      (ammgcv,type="pearson"),xlab="Predicted",ylab="Residuals")
qqnorm (residuals (ammgcv,type="pearson"), main="")
qqline(residuals (ammgcv,type="pearson"))
par(op)


############################################################################
##                        Non linear regression example                   ##
############################################################################

# Data description
# The stormer viscometer dataset contains measurements on the viscosity of a fluid, which
# is achieved by measuring the time taken for an inner cylinder in the viscometer to perform
# a fixed number of revolutions in response to some weight.
# The stormer viscometer measures the viscosity of a fluid by measuring the time taken for
# an inner cylinder in the mechanism to perform a fixed number of revolutions in response
# to an actuating weight. The viscometer is calibrated by measuring the time taken with
# varying weights while the mechanism is suspended in fluids of accurately known vis-
#   cosity. The data comes from such a calibration
# Viscosity: Viscosity of fluid
# Wt: Actuating weight
# Time: Time taken

rm(list=ls())

str(stormer)
head(stormer)

# theoretical considerations suggest a
# non-linear relationship between time, weight and viscosity are of the form
# T= beta*v/(W-theta) + epsilon
# Ignoring the error term and re-arranging the above expression gives:
# WT ~ beta*v+theta*T
# This relation may be used to obtain an initial estimate of beta and theta parameters:
b <- coef(lm(Wt*Time ~ Viscosity + Time - 1,stormer))
names(b) <- c("beta", "theta")
b

# Now non-linear estimation of parameters of initial equation:
storm.1 <- nls(Time ~ beta*Viscosity/(Wt - theta), stormer, start=b, trace=T)
summary(storm.1,correlation=TRUE)
