## ----intro_require_ggplot, message=FALSE---------------------------------
require(ggplot2)

## ----intro_data_bands, message=FALSE-------------------------------------
require(qdata)
data(bands)
head(bands)

