## ----first, include=TRUE, purl=TRUE, message=FALSE-----------------------
require(dplyr)
require(tidyr)
require(qdata)
require(ggplot2)

