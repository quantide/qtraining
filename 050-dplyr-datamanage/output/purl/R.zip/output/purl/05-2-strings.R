## ----first, include=TRUE, purl=TRUE, message=FALSE-----------------------
require(stringr)
require(forcats)
require(qdata)

