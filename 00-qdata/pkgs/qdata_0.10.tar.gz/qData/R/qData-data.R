##################################################################################################################################
#' bands: Cylinder bands
#' 
#' @name bands
#'
#'
#' @description This dataset is related with process delays known as cylinder banding in rotogravure printing.
#' 
#' The full dataset was described and analyzed in [Moro et al., 2011]., see \code{source} section.
#'
#'
#' @usage data(bands)
#' 
#' 
#' @format \code{bands} is a tbl data frame with 540 observations on 40 variables.
#' 
#'  
#' @details 
#' The 40 variables are organized as follows.
#' 
#' \itemize{
#' \item \code{timestamp} (numeric from 19900330 to 19941010);
#' \item \code{cylinder_number} (character);
#' \item \code{customer} (character);
#' \item \code{job_number} (numeric from 23040 to 88231) 
#' \item \code{grain_screened} (factor with 2 levels: YES, NO);
#' \item \code{ink_color} (factor with 1 level: KEY);
#' \item \code{proof_on_ctd_ink} (factor with 2 levels: YES, NO);
#' \item \code{blade_mfg} (factor with 2 levels: BENTON, UDDEHOLM);
#' \item \code{cylinder_division} (factor with 1 level: GALLATIN);
#' \item \code{paper_type} (factor with 3 level: UNCOATED, COATED, SUPER);
#' \item \code{ink_type} (factor with 3 level: UNCOATED, COATED, COVER); 
#' \item \code{direct_steam} (factor with 2 levels: YES, NO);
#' \item \code{solvent_type} (factor with 3 level: LINE, NAPTHA, XYLOL);
#' \item \code{type_on_cylinder} (factor with 2 levels: YES, NO);
#' \item \code{press_type} (factor with 4 levels: ALBERT70, MOTTER70, MOTTER94, WOODHOE70);
#' \item \code{press} (numeric from 802 to 828)
#' \item \code{unit_number}: printing unit (numeric: 1-10)
#' \item \code{cylinder_size} (factor with 3 levels: CATALOG, SPIEGEL, TABLOID);
#' \item \code{paper_mill_location} (factor with 5 levels: CANADIAN, MIDEUROPEAN, NORTHUS, SCANDANAVIAN, SOUTHUS);
#' \item \code{plating_tank} (numeric: 1910, 1911);
#' \item \code{proof_cut} measured in percentage (numeric: 0-100);
#' \item \code{viscosity} measured in percentage (numeric: 0-100);
#' \item \code{caliper} measured in percentage (numeric: 0-1);
#' \item \code{ink_temperature} measured in degrees Fahrenheit (numeric: 5-30);
#' \item \code{humidity} measured in percentage (numeric: 5-105);
#' \item \code{roughness} measured in microns (numeric: 0-2);
#' \item \code{blade_pressure} measured in pounds (numeric: 10-75);
#' \item \code{varnish_pct} measured in percentage (numeric: 0-100);
#' \item \code{press_speed} measured in feet per minute (numeric: 0-4000);
#' \item \code{ink_pct} measured in percentage (numeric: 0-100);
#' \item \code{solvent_pct} measured in percentage (numeric: 0-100);
#' \item \code{esa_voltage} measured in kilovolts (numeric: 0-16);
#' \item \code{esa_amperage} measured in milliamps (numeric: 0-10);
#' \item \code{wax} measured in gallons (numeric: 0-4);
#' \item \code{hardener} measured in gallons (numeric: 0-3.0);
#' \item \code{roller_durometer} (numeric: 15-120);
#' \item \code{current_density} measured in amperes per square decimeter (numeric: 20-50);
#' \item \code{anode_space_ratio} (numeric: 70-130);
#' \item \code{chrome_content} (numeric: 80-120);
#' \item \code{band_type} (factor with 2 levels: BAND, NOBAND).
#' }
#' 
#' 
#' @source This dataset is public available at \href{http://archive.ics.uci.edu/ml/datasets/Cylinder+Bands}{UCI Machine Learning repository}.
#' 
#' Please include this citation if you plan to use this dataset:\cr
#' Lichman, M. (2013). UCI Machine Learning Repository [\url{http://archive.ics.uci.edu/ml}]. Irvine, CA: University of California, School of Information and Computer Science.
#' 
#' The dataset was created and donated on 08 Jan 1995 to \href{http://archive.ics.uci.edu/ml/datasets/Cylinder+Bands}{UCI Machine Learning repository} by:\cr
#' Bob Evans 
#' RR Donnelley & Sons Co. 
#' Gallatin Division 
#' 801 Steam Plant Rd 
#' Gallatin, Tennessee 37066-3396 
#' (615) 452-5170 
NULL
##################################################################################################################################


##################################################################################################################################
#' bank: Marketing campaigns of a Portuguese banking institution
#' 
#' 
#' @name bank
#' @aliases bank1 bank2
#' 
#' 
#' @description This dataset is related with direct marketing campaigns of a Portuguese
#' banking institution. The marketing campaigns were based on phone calls. 
#' Often, more than one contact to the same client was required, in order to access if the product (bank term deposit) would be ('yes') or not ('no') subscribed. 
#' 
#' The full dataset was described and analyzed in [Moro et al., 2011]., see \code{source} section.
#' 
#'  
#' @usage data(bank) 
#' data(bank1) 
#' data(bank2)
#' 
#' 
#' @format \code{bank} is a tbl data frame with 45211 observations on 20 variables.
#' 
#' The data are ordered by call id (and also by date, from May 2008 to November 2010). 
#' 
#' \code{bank1} is a tbl data frame with all \code{bank} observations on 11 variables: the first 10 variables of \code{bank} and \code{duration}.
#' 
#' \code{bank2} is a tbl data frame with all \code{bank} observations on 11 variables: \code{id} and the last 10 variables of \code{bank}.
#' 
#' Differently from \code{bank}, \code{bank1} and \code{bank2} are not sorted by \code{id}.
#' 
#' 
#' @details 
#' The 20 variables are organized as follows.
#' 
#' Bank client data:
#' \itemize{
#' \item \code{id} phone call id (integer: from 1 to 45211);
#' \item \code{age} age (integer);
#' \item \code{job} type of job (factor with 12 levels: admin., unknown, unemployed, management, housemaid, entrepreneur, student,  blue-collar, self-employed, retired, technician, services);
#' \item \code{marital} marital status (factor with 3 levels: married, divorced, single). divorced means divorced or widowed;
#' \item \code{education} education (factor with 4 levels: unknown, secondary, primary, tertiary);
#' \item \code{default} has credit in default? (factor with 2 levels: yes, no);
#' \item \code{balance} average yearly balance, in euros (integer);
#' \item \code{housing} has housing loan? (factor with 2 levels: yes, no);
#' \item \code{loan} has personal loan? (factor with 2 levels: yes, no).
#' }
#' Related with the last contact of the current campaign:
#' \itemize{
#' \item \code{contact} contact communication type (factor with 3 levels: unknown, telephone, cellular);
#' \item \code{day} last contact day of the month (integer);
#' \item \code{month} last contact month of year (factor with 12 levels: jan, feb, mar, ..., nov, dec);
#' \item \code{year} last contact year (integer: 2008, 2009, 2010);
#' \item \code{date} last contact date (\code{POSIXct} date);
#' \item \code{duration} last contact duration, in seconds (integer);
#' \item \code{y} has the client subscribed a term deposit? (factor with 2 levels: yes, no).
#' }
#' Other attributes:
#' \itemize{
#' \item \code{campaign} number of contacts performed during this campaign and for this client (integer: it includes last contact);
#' \item \code{pdays} number of days that passed by after the client was last contacted from a previous campaign (integer). -1 means client who was not previously contacted;
#' \item \code{previous} number of contacts performed before this campaign and for this client (integer);
#' \item \code{poutcome} outcome of the previous marketing campaign (factor with 4 levels: "unknown", "other", "failure", "success").
#' }
#' 
#' 
#' @source This dataset is public available for research at \href{http://archive.ics.uci.edu/ml/datasets/Bank+Marketing}{UCI Machine Learning repository}.
#' The details are described in [Moro et al., 2011]. 
#' 
#' Please include this citation if you plan to use this dataset:\cr
#' [Moro et al., 2011] S. Moro, R. Laureano and P. Cortez. Using Data Mining for Bank Direct Marketing: An Application of the CRISP-DM Methodology.  
#' In P. Novais et al. (Eds.), \emph{Proceedings of the European Simulation and Modelling Conference - ESM'2011}, pp. 117-121, Guimarães, Portugal, October, 2011. EUROSIS.\cr
#' Available at \url{http://hdl.handle.net/1822/14838}.
NULL
##################################################################################################################################


##################################################################################################################################
#' italia: data on Italian districts
#' 
#' 
#' @name italia
#' @aliases comuni province regioni ripartizioni
#' 
#' 
#' @description The \code{italia} dataset is related with information on the 8003 Italian districts ("comuni") updated at 2016-01-01. 
#' In particular information on "province", "regioni, "ripartizioni" ("major" Italian districts) related to "comuni" is available.
#' 
#'  
#' @usage data(italia) 
#' data(comuni) 
#' data(province)
#' data(regioni)
#' data(ripartizioni)
#' 
#' 
#' @format \code{italia} is a tbl data frame with 8003 observations on 14 variables. It contains information on the 8003 Italian "comuni" and
#' all variables contained present also in the other tbl data frames (\code{comuni}, \code{province}, \code{regioni} and \code{ripartizioni}).
#' 
#' \code{comuni} is a tbl data frame with 8003 observations on 9 variables; it contains information on the 8003 Italian "comuni" and the codes of their major districts
#' ("province", "regioni", "ripartizioni").
#' 
#' \code{province} is a tbl data frame with 110 observations on 5 variables; it contains information on the 110 Italian "province" and on the 9 Italian metropolitan cities
#' ("città metropolitane").
#' 
#' \code{regioni} is a tbl data frame with 20 observations on 2 variables; it contains information on the 20 Italian "regioni".
#' 
#' \code{ripartizioni} is a tbl data frame with 5 observations on 2 variables; it contains information on the 5 Italian "ripartizioni".
#' 
#' 
#' @details 
#' The 14 variables of the \code{italia} tbl data frame are the following ones:
#' \itemize{
#' \item \code{cod_comune} codes of the Italian "comuni" (character);
#' \item \code{comune} names of the Italian "comuni" (character);
#' \item \code{comune_cap_prov} if a "comune" is the administrative center of the "provincia" (logical);
#' \item \code{pop_legale} legal population living in the "comuni" at the last "Censimento" (2011-10-09) (integer);
#' \item \code{progr_comune} progressive codes of the Italian "comuni" (it restarts from 1 for each "provincia") (character);
#' \item \code{cod_provincia} codes of the Italian "province"; note that \code{cod_comune} is \code{cod_provincia} pasted to \code{progr_comune} (character);
#' \item \code{provincia} names of the Italian "province" (character);
#' \item \code{sigla_auto} automotive initials ("targa automobilistica") of the Italian "province" (character);
#' \item \code{cod_citta_metro} codes of the Italian "città metropolitane" (character);
#' \item \code{citta_metro} names of the Italian "città metropolitane" (character);
#' \item \code{cod_regione} codes of the Italian "regioni" (character);
#' \item \code{regione} names of the Italian "regioni" (character);
#' \item \code{cod_rip_geo} codes of the Italian "ripartizioni geografiche" (character);
#' \item \code{rip_geo} names of the Italian "ripartizioni geografiche" (character).
#' }
#' 
#' 
#' @source This dataset was downloaded in the Istat website: \href{http://www.istat.it/it/archivio/6789}{Istituto nazionale di statistica (Istat)}.
NULL
##################################################################################################################################


##################################################################################################################################
#' people: data on 1806 Italian people
#' 
#' 
#' @name people
#' 
#' 
#' @description The \code{people} dataset is related with information on 1806 Italian people: their gender, area, weight and height.
#' 
#'  
#' @usage data(people)
#' 
#' 
#' @format \code{people} is a tbl data frame with 1806 observations on 4 variables.
#' 
#' 
#' @details 
#' The 4 variables of the \code{people} tbl data frame are the following ones:
#' \itemize{
#' \item \code{Gender} gender (factor with 2 levels: Female, Male);
#' \item \code{Area} residence area (factor with 4 levels: Centro, Isole, Nord, Sud);
#' \item \code{Weight} weight in kg (numeric);
#' \item \code{Height} height in cm (numeric).
#' }
NULL
##################################################################################################################################


##################################################################################################################################
#' mtcars: Motor Trend Car Road Tests 
#' 
#' 
#' @name mtcars
#' 
#' 
#' @description The \code{mtcars} data were extracted from the analogous tbl data frame of package \code{datasets}.
#' 
#'  
#' @usage data(mtcars)
#' 
#' 
#' @format \code{mtcars} is a tbl data frame with 32 observations on 5 variables.
#' 
#' 
#' @details 
#' The 5 variables of the \code{mtcars} tbl data frame are the following ones:
#' \itemize{
#' \item \code{car} car model (charcater);
#' \item \code{carb} Number of carburetors (numeric);
#' \item \code{cyl} Number of cylinders (numeric);
#' \item \code{mpg} Miles/(US) gallon (numeric);
#' \item \code{disp} Displacement (cu.in.) (numeric).
#' }
#' 
#' 
#' @seealso the complete \code{mtcars} help page in the \code{datatsets} package: \code{\link[datasets]{mtcars}}
NULL
##################################################################################################################################
