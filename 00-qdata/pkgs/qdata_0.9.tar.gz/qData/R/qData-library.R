##################################################################################################################################
#' bank
#' @description This dataset is related with direct marketing campaigns of a Portuguese
#' banking institution. The marketing campaigns were based on phone calls. The data are ordered by call id
#' (and also by date, from May 2008 to November 2010). The full dataset was described and analyzed in:
#' 
#' S. Moro, R. Laureano and P. Cortez. Using Data Mining for Bank Direct Marketing:
#' An Application of the CRISP-DM Methodology. In P. Novais et al. (Eds.),
#' Proceedings of the European Simulation and Modelling Conference -
#' ESM'2011, pp. 117-121, Guimarães, Portugal, October, 2011. EUROSIS.
#' 
#' @usage data(bank)
#' @format A data frame with 45211 rows (observations) and 20 columns (variables)
#' @details 
#' The 20 variables are organized as follows.
#' 
#' Bank client data:
#' \itemize{
#' \item `id`: phone call id (numeric: from 1 to 45211)
#' \item `age`: age (numeric)
#' \item `job`: type of job (categorical: admin., unknown, unemployed, management, housemaid, entrepreneur, student,  blue-collar, self-employed, retired, technician, services) 
#' \item `marital`: marital status (categorical: married, divorced, single; note: divorced means divorced or widowed)
#' \item `education`: education (categorical: unknown, secondary, primary, tertiary)
#' \item `default`: has credit in default? (binary: yes, no)
#' \item `balance`: average yearly balance, in euros (numeric)
#' \item `housing`: has housing loan? (binary: yes, no)
#' \item `loan`: has personal loan? (binary: yes, no)
#' }
#' Related with the last contact of the current campaign:
#' \itemize{
#' \item `contact`: contact communication type (categorical: unknown, telephone, cellular) 
#' \item `day`: last contact day of the month (numeric)
#' \item `month`: last contact month of year (categorical: jan, feb, mar, ..., nov, dec)
#' \item `year`: last contact year (numeric: 2008, 2009 or 2010)
#' \item `date`: last contact date (date)
#' \item `duration`: last contact duration, in seconds (numeric)
#' \item `y`: has the client subscribed a term deposit? (binary: yes, no)
#' }
#' Other attributes:
#' \itemize{
#' \item `campaign`: number of contacts performed during this campaign and for this client (numeric: it includes last contact)
#' \item `pdays`: number of days that passed by after the client was last contacted from a previous campaign (numeric: -1 means client who was not previously contacted)
#' \item `previous`: number of contacts performed before this campaign and for this client (numeric)
#' \item `poutcome`: outcome of the previous marketing campaign (categorical: "unknown", "other", "failure", "success")
#' }
#' 
#' @name bank
NULL
##################################################################################################################################


##################################################################################################################################
#' bank1
#' @description This dataset contains the first half of the variables of the bank dataset (see \code{\link{bank}}).
#' Differently from \code{bank}, it is not sorted by \code{id}.
#' 
#' @usage data(bank1)
#' @format A data frame with 45211 rows (observations) and 10 columns (variables)
#' @name bank1
NULL
##################################################################################################################################


##################################################################################################################################
#' bank2
#' @description This dataset contains the second half of the variables of the bank dataset (see \code{\link{bank}}).
#' Differently from \code{bank}, it is not sorted by \code{id}.
#' 
#' @usage data(bank2)
#' @format A data frame with 45211 rows (observations) and 11 columns (variables)
#' @name bank2
NULL
##################################################################################################################################
