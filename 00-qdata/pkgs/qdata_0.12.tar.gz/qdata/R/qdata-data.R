##################################################################################################################################
#' bands: Cylinder bands
#' 
#' @name bands
#'
#'
#' @description This dataset is related with process delays known as cylinder banding in rotogravure printing.
#' 
#' The full dataset was described and analyzed in [Moro et al., 2011]., see \code{source} section.
#'
#'
#' @usage data(bands)
#' 
#' 
#' @format \code{bands} is a tbl data frame with 540 observations on 40 variables.
#' 
#'  
#' @details 
#' The 40 variables are organized as follows.
#' 
#' \itemize{
#' \item \code{timestamp} (numeric from 19900330 to 19941010);
#' \item \code{cylinder_number} (character);
#' \item \code{customer} (character);
#' \item \code{job_number} (numeric from 23040 to 88231) 
#' \item \code{grain_screened} (factor with 2 levels: YES, NO);
#' \item \code{ink_color} (factor with 1 level: KEY);
#' \item \code{proof_on_ctd_ink} (factor with 2 levels: YES, NO);
#' \item \code{blade_mfg} (factor with 2 levels: BENTON, UDDEHOLM);
#' \item \code{cylinder_division} (factor with 1 level: GALLATIN);
#' \item \code{paper_type} (factor with 3 level: UNCOATED, COATED, SUPER);
#' \item \code{ink_type} (factor with 3 level: UNCOATED, COATED, COVER); 
#' \item \code{direct_steam} (factor with 2 levels: YES, NO);
#' \item \code{solvent_type} (factor with 3 level: LINE, NAPTHA, XYLOL);
#' \item \code{type_on_cylinder} (factor with 2 levels: YES, NO);
#' \item \code{press_type} (factor with 4 levels: ALBERT70, MOTTER70, MOTTER94, WOODHOE70);
#' \item \code{press} (numeric from 802 to 828)
#' \item \code{unit_number}: printing unit (numeric: 1-10)
#' \item \code{cylinder_size} (factor with 3 levels: CATALOG, SPIEGEL, TABLOID);
#' \item \code{paper_mill_location} (factor with 5 levels: CANADIAN, MIDEUROPEAN, NORTHUS, SCANDANAVIAN, SOUTHUS);
#' \item \code{plating_tank} (numeric: 1910, 1911);
#' \item \code{proof_cut} measured in percentage (numeric: 0-100);
#' \item \code{viscosity} measured in percentage (numeric: 0-100);
#' \item \code{caliper} measured in percentage (numeric: 0-1);
#' \item \code{ink_temperature} measured in degrees Fahrenheit (numeric: 5-30);
#' \item \code{humidity} measured in percentage (numeric: 5-105);
#' \item \code{roughness} measured in microns (numeric: 0-2);
#' \item \code{blade_pressure} measured in pounds (numeric: 10-75);
#' \item \code{varnish_pct} measured in percentage (numeric: 0-100);
#' \item \code{press_speed} measured in feet per minute (numeric: 0-4000);
#' \item \code{ink_pct} measured in percentage (numeric: 0-100);
#' \item \code{solvent_pct} measured in percentage (numeric: 0-100);
#' \item \code{esa_voltage} measured in kilovolts (numeric: 0-16);
#' \item \code{esa_amperage} measured in milliamps (numeric: 0-10);
#' \item \code{wax} measured in gallons (numeric: 0-4);
#' \item \code{hardener} measured in gallons (numeric: 0-3.0);
#' \item \code{roller_durometer} (numeric: 15-120);
#' \item \code{current_density} measured in amperes per square decimeter (numeric: 20-50);
#' \item \code{anode_space_ratio} (numeric: 70-130);
#' \item \code{chrome_content} (numeric: 80-120);
#' \item \code{band_type} (factor with 2 levels: BAND, NOBAND).
#' }
#' 
#' 
#' @source This dataset is publicly available at \href{http://archive.ics.uci.edu/ml/datasets/Cylinder+Bands}{UCI Machine Learning repository}.
#' 
#' Please include this citation if you plan to use this dataset:\cr
#' Lichman, M. (2013). UCI Machine Learning Repository [\url{http://archive.ics.uci.edu/ml}]. Irvine, CA: University of California, School of Information and Computer Science.
#' 
#' The dataset was created and donated on 08 Jan 1995 to \href{http://archive.ics.uci.edu/ml/datasets/Cylinder+Bands}{UCI Machine Learning repository} by:\cr
#' Bob Evans 
#' RR Donnelley & Sons Co. 
#' Gallatin Division 
#' 801 Steam Plant Rd 
#' Gallatin, Tennessee 37066-3396 
#' (615) 452-5170 
NULL
##################################################################################################################################


##################################################################################################################################
#' bank: Marketing campaigns of a Portuguese banking institution
#' 
#' 
#' @name bank
#' @aliases bank1 bank2
#' 
#' 
#' @description This dataset is related with direct marketing campaigns of a Portuguese
#' banking institution. The marketing campaigns were based on phone calls. 
#' Often, more than one contact to the same client was required, in order to access if the product (bank term deposit) would be ('yes') or not ('no') subscribed. 
#' 
#' The full dataset was described and analyzed in [Moro et al., 2011]., see \code{source} section.
#' 
#'  
#' @usage data(bank) 
#' 
#' 
#' @format \code{bank} is a tbl data frame with 45211 observations on 20 variables.
#' 
#' The data is ordered by call id (and also by date, from May 2008 to November 2010). 
#' 
#' \code{bank1} is a tbl data frame with all \code{bank} observations on 11 variables: the first 10 variables of \code{bank} and \code{duration}.
#' 
#' \code{bank2} is a tbl data frame with all \code{bank} observations on 11 variables: \code{id} and the last 10 variables of \code{bank}.
#' 
#' Differently from \code{bank}, \code{bank1} and \code{bank2} are not sorted by \code{id}.
#' 
#' 
#' @details 
#' The 20 variables are organized as follows.
#' 
#' Bank client data:
#' \itemize{
#' \item \code{id} phone call id (integer: from 1 to 45211);
#' \item \code{age} age (integer);
#' \item \code{job} type of job (factor with 12 levels: admin., unknown, unemployed, management, housemaid, entrepreneur, student,  blue-collar, self-employed, retired, technician, services);
#' \item \code{marital} marital status (factor with 3 levels: married, divorced, single). divorced means divorced or widowed;
#' \item \code{education} education (factor with 4 levels: unknown, secondary, primary, tertiary);
#' \item \code{default} has credit in default? (factor with 2 levels: yes, no);
#' \item \code{balance} average yearly balance, in euros (integer);
#' \item \code{housing} has housing loan? (factor with 2 levels: yes, no);
#' \item \code{loan} has personal loan? (factor with 2 levels: yes, no).
#' }
#' Related with the last contact of the current campaign:
#' \itemize{
#' \item \code{contact} contact communication type (factor with 3 levels: unknown, telephone, cellular);
#' \item \code{day} last contact day of the month (integer);
#' \item \code{month} last contact month of year (factor with 12 levels: jan, feb, mar, ..., nov, dec);
#' \item \code{year} last contact year (integer: 2008, 2009, 2010);
#' \item \code{date} last contact date (\code{POSIXct} date);
#' \item \code{duration} last contact duration, in seconds (integer);
#' \item \code{y} has the client subscribed a term deposit? (factor with 2 levels: yes, no).
#' }
#' Other attributes:
#' \itemize{
#' \item \code{campaign} number of contacts performed during this campaign and for this client (integer: it includes last contact);
#' \item \code{pdays} number of days that passed by after the client was last contacted from a previous campaign (integer). -1 means client who was not previously contacted;
#' \item \code{previous} number of contacts performed before this campaign and for this client (integer);
#' \item \code{poutcome} outcome of the previous marketing campaign (factor with 4 levels: "unknown", "other", "failure", "success").
#' }
#' 
#' 
#' @source This dataset is publicly available for research at \href{http://archive.ics.uci.edu/ml/datasets/Bank+Marketing}{UCI Machine Learning repository}.
#' The details are described in [Moro et al., 2011]. 
#' 
#' Please include this citation if you plan to use this dataset:\cr
#' [Moro et al., 2011] S. Moro, R. Laureano and P. Cortez. Using Data Mining for Bank Direct Marketing: An Application of the CRISP-DM Methodology.  
#' In P. Novais et al. (Eds.), \emph{Proceedings of the European Simulation and Modelling Conference - ESM'2011}, pp. 117-121, Guimarães, Portugal, October, 2011. EUROSIS.\cr
#' Available at \url{http://hdl.handle.net/1822/14838}.
NULL
##################################################################################################################################


##################################################################################################################################
#' banknotes: Motor Trend Car Road Tests 
#' 
#' 
#' @name banknotes
#' 
#' 
#' @description This dataset deals with 200 old Swiss 1,000-franc banknotes classified by dimensions (6 numerical characteristics) and type (genuine/counterfeit).
#' The first 100 banknotes are genuine, the last 100 are counterfeit.
#' 
#'  
#' @usage data(banknotes)
#' 
#' 
#' @format \code{banknotes} is a tbl data frame with 200 observations on 7 variables.
#' 
#' 
#' @details 
#' The 7 variables of the \code{banknotes} tbl data frame are the following ones:
#' \itemize{
#' \item \code{length} length of the banknote (numeric);
#' \item \code{left} height of the banknote, measured on the left (cu.in.) (numeric);
#' \item \code{right} height of the banknote, measured on the right (numeric);
#' \item \code{bottom} distance of inner frame to the lower border (numeric);
#' \item \code{top} distance of inner frame to the upper border (numeric);
#' \item \code{diagonal} length of the diagonal (numeric);
#' \item \code{type} if the banknote is genuine or counterfeit (Factor).
#' }
#' 
#' 
#' @source Härdle and Simar, Applied Multivariate Statistical Analysis, 3rd ed., Springer, 2012
NULL
##################################################################################################################################


##################################################################################################################################
#' bimetal1: Motor Trend Car Road Tests 
#' 
#' 
#' @name bimetal1
#' 
#' 
#' @description The \code{bimetal1} data was extracted from the analogous dataset of package \code{MSQC}.
#' 
#'  
#' @usage data(bimetal1)
#' 
#' 
#' @format \code{bimetal1} is a tbl data frame with 28 observations on 5 variables.
#' 
#' 
#' @details 
#' The 5 variables of the \code{bimetal1} tbl data frame are the following ones:
#' \itemize{
#' \item \code{car} car model (character);
#' \item \code{disp} displacement (cu.in.) (numeric).
#' }
#' 
#' 
#' @seealso the complete \code{bimetal1} help page is in the \code{MSQC} package: \code{\link[MSQC]{bimetal1}}
NULL
##################################################################################################################################


##################################################################################################################################
#' bostonhousing: Motor Trend Car Road Tests 
#' 
#' 
#' @name bostonhousing
#' 
#' 
#' @description The \code{bostonhousing} data deals with 506 houses in Boston classified by 13 numerical characteristics
#' (age, tax, etc.) and one categorical characteristic (chas).
#' 
#'  
#' @usage data(bostonhousing)
#' 
#' 
#' @format \code{bostonhousing} is a tbl data frame with 506 observations on 14 variables.
#' 
#' 
#' @details 
#' The 14 variables of the \code{bostonhousing} tbl data frame are the following ones:
#' \itemize{
#' \item \code{rm} number of rooms per dwelling (numeric);
#' \item \code{lstat} lower status of the population (numeric);
#' \item \code{medv} median value of the house (in USD 1000) (numeric).
#' }
NULL
##################################################################################################################################


##################################################################################################################################
#' default: Motor Trend Car Road Tests 
#' 
#' 
#' @name default
#' 
#' 
#' @description The \code{default} data was extracted from ...........
#' 
#'  
#' @usage data(default)
#' 
#' 
#' @format \code{default} is a tbl data frame with 30000 observations on 25 variables.
#' 
#' 
#' @details 
#' The 25 variables of the \code{default} tbl data frame are the following ones:
#' \itemize{
#' \item \code{car} car model (character);
#' \item \code{disp} displacement (cu.in.) (numeric).
#' }
NULL
##################################################################################################################################


##################################################################################################################################
#' diabetes: Diabetes patient records
#' 
#' 
#' @name diabetes
#' 
#' 
#' @description Insulin Dependent Diabetes Mellitus (IDDM) data for the AAAI Spring Symposium (1994).
#' 
#'  
#' @usage data(diabetes)
#' 
#' 
#' @format \code{diabetes} is a tbl data frame with 30264 observations on 5 variables.
#' 
#' 
#' @details 
#' Diabetes patient records were obtained from two sources: an automatic electronic recording device and paper records. The automatic device had an internal clock to timestamp events, whereas the paper records only provided "logical time" slots (breakfast, lunch, dinner, bedtime).  For paper records, fixed times were assigned to breakfast (08:00), lunch (12:00), dinner (18:00), and bedtime (22:00).  Thus paper records have fictitious uniform recording times whereas electronic records have more realistic time stamps. 
#' 
#' Data has five variables:
#' \itemize{
#' \item \code{patient} id (character), this correspond to a single file on original data
#' \item \code{date} in MM-DD-YYYY format (factor)
#' \item \code{time} in XX:YY format (factor)
#' \item \code{code} indicates a task, according to the following list (integer)
  #' \itemize{  
  #' \item 33 = Regular insulin dose
  #' \item 34 = NPH insulin dose
  #' \item 35 = UltraLente insulin dose
  #' \item 48 = Unspecified blood glucose measurement
  #' \item 57 = Unspecified blood glucose measurement
  #' \item 58 = Pre-breakfast blood glucose measurement
  #' \item 59 = Post-breakfast blood glucose measurement
  #' \item 60 = Pre-lunch blood glucose measurement
  #' \item 61 = Post-lunch blood glucose measurement
  #' \item 62 = Pre-supper blood glucose measurement
  #' \item 63 = Post-supper blood glucose measurement
  #' \item 64 = Pre-snack blood glucose measurement
  #' \item 65 = Hypoglycemic symptoms
  #' \item 66 = Typical meal ingestion
  #' \item 67 = More-than-usual meal ingestion
  #' \item 68 = Less-than-usual meal ingestion
  #' \item 69 = Typical exercise activity
  #' \item 70 = More-than-usual exercise activity
  #' \item 71 = Less-than-usual exercise activity
  #' \item 72 = Unspecified special event
#' }
#' \item \code{value} insuline value (character)
#' }
#' 
#' @source This dataset is publicly available at \href{http://archive.ics.uci.edu/ml/datasets/Diabetes}{UCI Machine Learning repository}.
NULL
##################################################################################################################################


##################################################################################################################################
#' druguse: Motor Trend Car Road Tests 
#' 
#' 
#' @name druguse
#' 
#' 
#' @description The \code{druguse} data contains the correlation matrix among rates (recorded on a 5-point scale)
#' for a sample of 1,634 students in the seventh to ninth grades in 11 schools in the greater metropolitan area
#' of Los Angeles. Each participant completed a questionnaire about the number of times a particular substance had ever been used.
#' 
#'  
#' @usage data(druguse)
#' 
#' 
#' @format \code{druguse} is a 13 x 13 correlation matrix.
#' 
#' 
#' @details 
#' The 13 substances asked about, which are also the row and columns names of the matrix, were the following ones:
#' \itemize{
#' \item \code{cigarettes};
#' \item \code{beer};
#' \item \code{wine};
#' \item \code{liquor};
#' \item \code{cocaine};
#' \item \code{tranquillizers};
#' \item \code{drug store medications} used to get high;
#' \item \code{heroin} and other opiates;
#' \item \code{marijuana};
#' \item \code{hashish};
#' \item \code{inhalants} (glue, gasoline, etc.);
#' \item \code{hallucinogenics} (LSD, mescaline, etc.);
#' \item \code{amphetamine} stimulants.
#' }
#' 
#' 
#' @source Everitt, B. and Hothorn, T., *An Introduction to Applied Multivariate Analysis with `R`*, Springer, 2011
NULL
##################################################################################################################################


##################################################################################################################################
#' forbes94: Motor Trend Car Road Tests 
#' 
#' 
#' @name forbes94
#' 
#' 
#' @description The \code{forbes94} data deals with the compensation received in 1994 by the 800 most paid CEOs in US
#' (This dataset comes from a ranking published by the Forbes newspaper in the same year).
#' 
#'  
#' @usage data(forbes94)
#' 
#' 
#' @format \code{forbes94} is a tbl data frame with 800 observations on 30 variables.
#' 
#' 
#' @details 
#' The 30 variables of the \code{forbes94} tbl data frame are the following ones:
#' \itemize{
#' \item \code{car} car model (character);
#' \item \code{disp} displacement (cu.in.) (numeric).
#' }
NULL
##################################################################################################################################


##################################################################################################################################
#' g1res: Motor Trend Car Road Tests 
#' 
#' 
#' @name g1res
#' 
#' 
#' @description The \code{g1res} data was ......
#' 
#'  
#' @usage data(g1res)
#' 
#' 
#' @format \code{g1res} is a tbl data frame with 19 observations on 3 variables.
#' 
#' 
#' @details 
#' The 3 variables of the \code{g1res} tbl data frame are the following ones:
#' \itemize{
#' \item \code{car} car model (character);
#' \item \code{disp} displacement (cu.in.) (numeric).
#' }
NULL
##################################################################################################################################


##################################################################################################################################
#' german: Motor Trend Car Road Tests 
#' 
#' 
#' @name german
#' @aliases germannumeric germanstring
#' 
#' 
#' @description The \code{german} data deals with a sample of 1,000 customers which apply for a credit card. Some have defaulted
#' (Bad class) and other not (Good) on the credit card. 20 further characteristics about them or their credit card have been measured. 
#' 
#'  
#' @usage data(german)
#' 
#' 
#' @format \code{german} is a tbl data frame with 1000 observations on 21 variables.
#' 
#' 
#' @details 
#' The 21 variables of the \code{german} tbl data frame are the following ones:
#' \itemize{
#' \item \code{car} car model (character);
#' \item \code{disp} displacement (cu.in.) (numeric).
#' }
NULL
##################################################################################################################################


##################################################################################################################################
#' life: Motor Trend Car Road Tests 
#' 
#' 
#' @name life
#' 
#' 
#' @description The \code{life} data contains life expectations in years at birth, 25, 50 and 75 years for men and women in 31 Countries or regions.
#' 
#'  
#' @usage data(life)
#' 
#' 
#' @format \code{life} is a tbl data frame with 31 observations on 9 variables.
#' 
#' 
#' @details 
#' The 9 variables of the \code{life} tbl data frame are the following ones:
#' \itemize{
#' \item \code{country} (character);
#' \item \code{m0} life expectation in years for men at birth (numeric);
#' \item \code{m25} life expectation in years for men at 25 (numeric);
#' \item \code{m50} life expectation in years for men at 50 (numeric);
#' \item \code{m75} life expectation in years for men at 75 (numeric);
#' \item \code{m0} life expectation in years for women at birth (numeric);
#' \item \code{m25} life expectation in years for women at 25 (numeric);
#' \item \code{m50} life expectation in years for women at 50 (numeric);
#' \item \code{m75} life expectation in years for women at 75 (numeric).
#' }
#' 
#' 
#' @source Everitt, B. and Hothorn, T., An Introduction to Applied Multivariate Analysis with R, Springer, 2011
NULL
##################################################################################################################################


##################################################################################################################################
#' italia: data on Italian districts
#' 
#' 
#' @name italia
#' @aliases comuni province regioni ripartizioni
#' 
#' 
#' @description The \code{italia} dataset is related with information on the 8003 Italian districts ("comuni") updated at 2016-01-01. 
#' In particular information on "province", "regioni, "ripartizioni" ("major" Italian districts) related to "comuni" is available.
#' 
#'  
#' @usage data(italia) 
#' 
#' 
#' @format \code{italia} is a tbl data frame with 8003 observations on 14 variables. It contains information on the 8003 Italian "comuni" and
#' all variables contained present also in the other tbl data frames (\code{comuni}, \code{province}, \code{regioni} and \code{ripartizioni}).
#' 
#' \code{comuni} is a tbl data frame with 8003 observations on 9 variables; it contains information on the 8003 Italian "comuni" and the codes of their major districts
#' ("province", "regioni", "ripartizioni").
#' 
#' \code{province} is a tbl data frame with 110 observations on 5 variables; it contains information on the 110 Italian "province" and on the 9 Italian metropolitan cities
#' ("città metropolitane").
#' 
#' \code{regioni} is a tbl data frame with 20 observations on 2 variables; it contains information on the 20 Italian "regioni".
#' 
#' \code{ripartizioni} is a tbl data frame with 5 observations on 2 variables; it contains information on the 5 Italian "ripartizioni".
#' 
#' 
#' @details 
#' The 14 variables of the \code{italia} tbl data frame are the following ones:
#' \itemize{
#' \item \code{cod_comune} codes of the Italian "comuni" (character);
#' \item \code{comune} names of the Italian "comuni" (character);
#' \item \code{comune_cap_prov} if a "comune" is the administrative center of the "provincia" (logical);
#' \item \code{pop_legale} legal population living in the "comuni" at the last "Censimento" (2011-10-09) (integer);
#' \item \code{progr_comune} progressive codes of the Italian "comuni" (it restarts from 1 for each "provincia") (character);
#' \item \code{cod_provincia} codes of the Italian "province"; note that \code{cod_comune} is \code{cod_provincia} pasted to \code{progr_comune} (character);
#' \item \code{provincia} names of the Italian "province" (character);
#' \item \code{sigla_auto} automotive initials ("targa automobilistica") of the Italian "province" (character);
#' \item \code{cod_citta_metro} codes of the Italian "città metropolitane" (character);
#' \item \code{citta_metro} names of the Italian "città metropolitane" (character);
#' \item \code{cod_regione} codes of the Italian "regioni" (character);
#' \item \code{regione} names of the Italian "regioni" (character);
#' \item \code{cod_rip_geo} codes of the Italian "ripartizioni geografiche" (character);
#' \item \code{rip_geo} names of the Italian "ripartizioni geografiche" (character).
#' }
#' 
#' 
#' @source This dataset was downloaded in the Istat website: \href{http://www.istat.it/it/archivio/6789}{Istituto nazionale di statistica (Istat)}.
NULL
##################################################################################################################################


##################################################################################################################################
#' mds: Motor Trend Car Road Tests 
#' 
#' 
#' @name mds
#' 
#' 
#' @description The \code{mds} dataset is fictional and contains 10 observations on which 5 numerical variables are measured.
#' 
#'  
#' @usage data(mds)
#' 
#' 
#' @format \code{mds} is a tbl data frame with 10 observations on 5 variables.
#' 
#' 
#' @details 
#' The 5 variables of the \code{mds} tbl data frame are the following ones:
#' \itemize{
#' \item \code{car} car model (character);
#' \item \code{disp} displacement (cu.in.) (numeric).
#' }
NULL
##################################################################################################################################


##################################################################################################################################
#' mtcars: Motor Trend Car Road Tests 
#' 
#' 
#' @name mtcars
#' 
#' 
#' @description The \code{mtcars} data was extracted from the analogous tbl data frame of package \code{datasets}, included in the base \code{R} distribution.
#' 
#'  
#' @usage data(mtcars)
#' 
#' 
#' @format \code{mtcars} is a tbl data frame with 32 observations on 5 variables.
#' 
#' 
#' @details 
#' The 5 variables of the \code{mtcars} tbl data frame are the following ones:
#' \itemize{
#' \item \code{car} car model (character);
#' \item \code{carb} number of carburetors (numeric);
#' \item \code{cyl} number of cylinders (numeric);
#' \item \code{mpg} miles/(US) gallon (numeric);
#' \item \code{disp} displacement (cu.in.) (numeric).
#' }
#' 
#' 
#' @seealso the complete \code{mtcars} help page is in the \code{datasets} package: \code{\link[datasets]{mtcars}}
NULL
##################################################################################################################################


##################################################################################################################################
#' people: data on 1806 Italian people
#' 
#' 
#' @name people
#' 
#' 
#' @description The \code{people} dataset is related with information on 1806 Italian people: their gender, area, weight and height.
#' 
#'  
#' @usage data(people)
#' 
#' 
#' @format \code{people} is a tbl data frame with 1806 observations on 4 variables.
#' 
#' 
#' @details 
#' The 4 variables of the \code{people} tbl data frame are the following ones:
#' \itemize{
#' \item \code{Gender} gender (factor with 2 levels: Female, Male);
#' \item \code{Area} residence area (factor with 4 levels: Centro, Isole, Nord, Sud);
#' \item \code{Weight} weight in kg (numeric);
#' \item \code{Height} height in cm (numeric).
#' }
NULL
##################################################################################################################################


##################################################################################################################################
#' pimaindiansdiabetes2: Motor Trend Car Road Tests 
#' 
#' 
#' @name pimaindiansdiabetes2
#' 
#' 
#' @description The \code{pimaindiansdiabetes2} data was extracted from the analogous tbl data frame of package \code{datasets}.
#' 
#'  
#' @usage data(pimaindiansdiabetes2)
#' 
#' 
#' @format \code{pimaindiansdiabetes2} is a tbl data frame with 768 observations on 9 variables.
#' 
#' 
#' @details 
#' The 9 variables of the \code{pimaindiansdiabetes2} tbl data frame are the following ones:
#' \itemize{
#' \item \code{car} car model (character);
#' \item \code{disp} displacement (cu.in.) (numeric).
#' }
NULL
##################################################################################################################################


##################################################################################################################################
#' prostate: Motor Trend Car Road Tests 
#' 
#' 
#' @name prostate
#' 
#' 
#' @description The \code{prostate} data was ......
#' 
#'  
#' @usage data(prostate)
#' 
#' 
#' @format \code{prostate} is a tbl data frame with 97 observations on 9 variables.
#' 
#' 
#' @details 
#' The 9 variables of the \code{prostate} tbl data frame are the following ones:
#' \itemize{
#' \item \code{car} car model (character);
#' \item \code{disp} displacement (cu.in.) (numeric).
#' }
NULL
##################################################################################################################################


##################################################################################################################################
#' sres: Motor Trend Car Road Tests 
#' 
#' 
#' @name sres
#' 
#' 
#' @description The \code{sres} data was .....
#' 
#'  
#' @usage data(sres)
#' 
#' 
#' @format \code{sres} is a tbl data frame with 19 observations on 3 variables.
#' 
#' 
#' @details 
#' The 3 variables of the \code{sres} tbl data frame are the following ones:
#' \itemize{
#' \item \code{car} car model (character);
#' \item \code{disp} displacement (cu.in.) (numeric).
#' }
NULL
##################################################################################################################################


##################################################################################################################################
#' uscompanies: Motor Trend Car Road Tests 
#' 
#' 
#' @name uscompanies
#' 
#' 
#' @description The \code{uscompanies} data deals with 79 U.S. companies classified by 6 numerical characteristics (assets, sales, etc.)
#' and one categorical characteristic (industry); indshort is a shortening for industry.
#' 
#'  
#' @usage data(uscompanies)
#' 
#' 
#' @format \code{uscompanies} is a tbl data frame with 79 observations on 9 variables.
#' 
#' 
#' @details 
#' The 9 variables of the \code{uscompanies} tbl data frame are the following ones:
#' \itemize{
#' \item \code{company} car model (Factor);
#' \item \code{assets} (USD) (integer);
#' \item \code{sales} (USD) (integer);
#' \item \code{value} market value (USD) (integer);
#' \item \code{profits} (USD) (numeric);
#' \item \code{cashflow} (USD) (numeric);
#' \item \code{employees} (numeric);
#' \item \code{industry} (Factor);
#' \item \code{indshort} industry in a less fine classification (Factor);
#' }
#' 
#' 
#' @source Härdle and Simar, Applied Multivariate Statistical Analysis, 3rd ed., Springer, 2012
NULL
##################################################################################################################################


##################################################################################################################################
#' uscrime: Motor Trend Car Road Tests 
#' 
#' 
#' @name uscrime
#' 
#' 
#' @description The \code{uscrime} data deals with crime rates (number of crimes per 100,000 residents) in the 50 U.S.;
#' the dataset includes also land and population (in 1985) of the 50 U.S., which are classified by the following seven categories:
#' murder, rape, robbery, assault, burglary, larceny and auto-theft.
#' 
#'  
#' @usage data(uscrime)
#' 
#' 
#' @format \code{uscrime} is a tbl data frame with 50 observations on 12 variables.
#' 
#' 
#' @details 
#' The 12 variables of the \code{uscrime} tbl data frame are the following ones:
#' \itemize{
#' \item \code{state} car model (character);
#' \item \code{land} land (integer);
#' \item \code{popu1985} population in 1985 (integer);
#' \item \code{murd} murder (numeric);
#' \item \code{rape} rape (numeric);
#' \item \code{robb} rabbery (numeric);
#' \item \code{assa} assault (integer);
#' \item \code{burg} burglary (integer);
#' \item \code{larc} larceny (integer);
#' \item \code{auto} auto-theft (integer);
#' \item \code{reg} ??? (integer);
#' \item \code{div} ??? (integer).
#' }
#' 
#' 
#' @source Härdle, W. K. and Simar, L., Applied Multivariate Statistical Analysis, 3rd edition, Springer, 2012
NULL
##################################################################################################################################


##################################################################################################################################
#' utilities: Motor Trend Car Road Tests 
#' 
#' 
#' @name utilities
#' 
#' 
#' @description The \code{utilities} data deals with 22 U.S. companies classified by 8 numerical characteristics (coverage, return, cost, etc.).
#' 
#'  
#' @usage data(utilities)
#' 
#' 
#' @format \code{utilities} is a tbl data frame with 22 observations on 10 variables.
#' 
#' 
#' @details 
#' The 10 variables of the \code{utilities} tbl data frame are the following ones:
#' \itemize{
#' 
#' \item \code{coverage} fixed-charge coverage ratio (income/debt) (numeric);
#' \item \code{return} rate of return on capital (numeric);
#' \item \code{cost} cost per kW capacity in place (integer);
#' \item \code{load} annual load factor (numeric);
#' \item \code{peak} peak kWh demand growth from 1974 to 1975 (numeric);
#' \item \code{sales} sales (kWh use per year) (integer);
#' \item \code{nuclear} percent nuclear (numeric);
#' \item \code{fuel} total fuel costs (cents per kWh) (numeric);
#' \item \code{company} company full name (character);
#' \item \code{comp_short} company short name (character).
#' }
NULL
##################################################################################################################################


##################################################################################################################################
#' volcano3d: Topographic Information on Auckland's Maunga Whau Volcano
#' 
#' 
#' @name volcano3d
#' 
#' 
#' @description The \code{volcano3d} data was derived from the \code{volcano} dataset included in the base \code{R} distribution,
#' and gives the topographic information for Maunga Whau, one of about 50 volcanos in the Auckland volcanic field, on a 10m by 10m grid. 
#' 
#'  
#' @usage data(volcano3d)
#' 
#' 
#' @format \code{volcano3d} is a tbl data frame with 5307 observations on 3 variables.
#' 
#' 
#' @details 
#' The 3 variables of the \code{volcano3d} tbl data frame are the following ones:
#' \itemize{
#' \item \code{car} car model (character);
#' \item \code{disp} displacement (cu.in.) (numeric).
#' }
#' 
#' 
#' @seealso the \code{volcano} help page in the \code{datasets} package: \code{\link[datasets]{volcano}}
NULL
##################################################################################################################################


##################################################################################################################################
#' wea: Motor Trend Car Road Tests 
#' 
#' 
#' @name wea
#' 
#' 
#' @description The \code{wea} data deals with weather daily data (temperature, rain, wind, etc.) in Canberra, Australia,
#' from 2007-11-01 to 2008-10-31.
#' 
#'  
#' @usage data(wea)
#' 
#' 
#' @format \code{wea} is a tbl data frame with 366 observations on 24 variables.
#' 
#' 
#' @details 
#' The 5 variables of the \code{wea} tbl data frame are the following ones:
#' \itemize{
#' \item \code{car} car model (character);
#' \item \code{disp} displacement (cu.in.) (numeric).
#' }
NULL
##################################################################################################################################


##################################################################################################################################
#' wines: Motor Trend Car Road Tests 
#' 
#' 
#' @name wines
#' 
#' 
#' @description The \code{wines} data was extracted from the analogous dataset of package \code{kohonen} and contains information
#' on a set of 177 Italian wine samples from three different grape cultivars; 13 variables have been measured (alcohol, malic acid, tc.).
#' 
#'  
#' @usage data(wines)
#' 
#' 
#' @format \code{wines} is a tbl data frame with 177 observations on 13 variables.
#' 
#' 
#' @details 
#' The 13 variables of the \code{wines} tbl data frame are the following ones:
#' \itemize{
#' \item \code{car} car model (character);
#' \item \code{disp} displacement (cu.in.) (numeric).
#' }
#' 
#' 
#' @seealso the complete \code{wines} help page in the \code{kohonen} package: \code{\link[kohonen]{wines}}
NULL
##################################################################################################################################


##################################################################################################################################
#' wwiileaders: Motor Trend Car Road Tests 
#' 
#' 
#' @name wwiileaders
#' 
#' 
#' @description The \code{wwiileaders} data contains a distance matrix among 12 country leaders during II World War,
#' which is based on the judgments of the dissimilarities in ideology. The subjects made judgments on a nine-point scale,
#' with the extreme points of the scale, 1 and 9, being described as indicating “very similar” and “very dissimilar”, respectively.
#' 
#'  
#' @usage data(wwiileaders)
#' 
#' 
#' @format \code{wwiileaders} is a distance matrix.
#' 
#' 
#' @source Everitt, B. and Hothorn, T., *An Introduction to Applied Multivariate Analysis with `R`*, Springer, 2011
NULL
##################################################################################################################################


