## ---- eval=FALSE---------------------------------------------------------
## install.packages("rmarkdown")

## ----eval=FALSE----------------------------------------------------------
## require(rmarkdown)
## render("example.Rmd")

